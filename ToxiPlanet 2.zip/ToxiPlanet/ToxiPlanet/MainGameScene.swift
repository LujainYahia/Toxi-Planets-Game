//
//  MainGame.swift
//  ToxiPlanet
//
//  Created by Lujain Yhia on 27/10/1445 AH.
//

import Foundation


import SpriteKit
import GameplayKit

enum PhysicsCategory: UInt32 {
   
    case None = 1
    case wall = 2
    case player = 3
    case resident = 5
    case resident2 = 6
    case resident3 = 7
    case BlackHole = 8
}



class MainGameScene: SKScene, SKPhysicsContactDelegate {
    
    var maze : SKNode?
    var toxi: Player?
    var resident: Resident?
//    let whiteResi = Resident()
//    let redResi = Resident()
//    let greenResi = Resident()
    
    var blankNodes: [CGPoint] = [CGPoint]()
    var blackHole :SKSpriteNode!
    
    func test(){
        print("MainGameScene")
    }
    
    func setPlayerResident(toxi: Player, resident: Resident) {
        
        self.toxi = toxi
        self.resident = resident
        
        if self.toxi != nil {
            addChild(self.toxi!)
        }

    }
    
    override func didMove(to view: SKView) {
        
        
        //find the maze node
        for node in self.children{
            if node is SKTileMapNode {
                if let map: SKTileMapNode = node as? SKTileMapNode {
                    print("map exists")
                    setWalls(maze: map)
                    maze = map
                }
            }
        }
        let texture = SKTexture(imageNamed: "Hole")
        
        blackHole = SKSpriteNode(texture: texture, size: CGSize(width: 25, height: 25))
        blackHole.position = CGPoint(x: -190, y: -130)
        blackHole.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        blackHole.physicsBody?.isDynamic = false
        blackHole.physicsBody?.affectedByGravity = false
        blackHole.physicsBody?.categoryBitMask = PhysicsCategory.BlackHole.rawValue
        blackHole.physicsBody?.collisionBitMask = PhysicsCategory.player.rawValue
        blackHole.physicsBody?.collisionBitMask = PhysicsCategory.player.rawValue
        maze?.addChild(blackHole)
        
        if self.resident != nil {
            maze?.addChild(self.resident!)
        }

        
//        maze?.addChild(resident)
//        addChild(toxi)

//        maze.addChild(redResi)
//        maze.addChild(greenResi)
        print("Toxi is here")
        physicsWorld.contactDelegate = self
    }//this method adds nodes that will show in the scene
    
    
    // Handle touch events
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let touchLocation = touch.location(in: self)
        let touchedNode = self.atPoint(touchLocation)
        
        // Check if the touch is on the node
        if touchedNode == maze {
            // Record the initial touch location
            maze?.userData = NSMutableDictionary()
            maze?.userData?.setValue(touchLocation, forKey: "startTouch")
        }
    }
    
    // Rotate the node as the touch moves
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first, let node = maze else { return }
        let touchLocation = touch.location(in: self)
        let previousLocation = touch.previousLocation(in: self)
        
        let angle = atan2(touchLocation.y - node.position.y, touchLocation.x - node.position.x) - atan2(previousLocation.y - node.position.y, previousLocation.x - node.position.x)
        
        node.zRotation += angle
    }
    // Reset user data
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        maze?.userData = nil
    }
    
    //    // Reset user data
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        maze?.userData = nil
    }
    
    func setWalls(maze: SKTileMapNode){
        var scenePoint = CGPoint()
        for row in 0..<maze.numberOfRows {
            for col in 0..<maze.numberOfColumns {
                scenePoint = gridToCoord(column: col, row: row)
                if let tile = maze.tileDefinition(atColumn: col, row: row){
                    if tile.name == "Blank" {
                        //store in blankPoints array
                        blankNodes.append(scenePoint)
                    }
                    else {
                        let wall : SKSpriteNode = SKSpriteNode()
                        
                        //add physics features to the node
                        wall.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: maze.tileSize.width, height: maze.tileSize.height))
                        wall.physicsBody?.isDynamic = false
                        wall.physicsBody?.affectedByGravity = false
                        wall.physicsBody?.categoryBitMask = PhysicsCategory.wall.rawValue
                        wall.physicsBody?.collisionBitMask = PhysicsCategory.player.rawValue
                        wall.physicsBody?.contactTestBitMask = PhysicsCategory.player.rawValue
                        
                        //define position of node
                        wall.position = CGPoint(x: scenePoint.x, y: scenePoint.y)
                        let wallParent = SKNode()
                        wallParent.position = CGPoint(x: -240, y: -240)
                        
                        wallParent.zPosition = 1
                        
                        wallParent.addChild(wall)
                        maze.addChild(wallParent)
                        print("wall is added")
                        
                    }
                }
                
                
                
            }
        }
    }
    
    
    
    //convert grid points coordinates
    func gridToCoord(column: Int, row: Int, tileSize: CGSize = CGSize(width: 30, height: 30), xOffset: Double = 0) -> CGPoint {
        
        let xCoord : Double = Double(column) * tileSize.width + (tileSize.width / 2) + xOffset
        let yCoord: Double = Double(row) * tileSize.height + (tileSize.height / 2)
        return CGPoint(x: xCoord, y: yCoord)
    }
    
    
    //    // Handle collision events
    func didBegin(_ contact: SKPhysicsContact) {
        let collision = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        
        // Check if the collision involves the ball and the wall
        //        if collision == PhysicsCategory.player.rawValue | PhysicsCategory.wall.rawValue {
        //            // print("Ball hit the wall!")
        //        }
        
        if collision == PhysicsCategory.player.rawValue | PhysicsCategory.resident.rawValue{
            print("eat white")
//            whiteResi.removeAllChildren()
            
            if contact.bodyA.categoryBitMask == PhysicsCategory.resident.rawValue {
                contact.bodyA.node?.removeFromParent()
            }
            if contact.bodyB.categoryBitMask == PhysicsCategory.resident.rawValue {
                contact.bodyB.node?.removeFromParent()
            }
            

        }
        
        else if collision == PhysicsCategory.player.rawValue | PhysicsCategory.BlackHole.rawValue {
            print("toxi end")
            toxi?.removeAllChildren()
            
            
            //                } else if contact.bodyA.categoryBitMask == Collision.FinishHole || contact.bodyB.categoryBitMask == Collision.FinishHole {
            //                    alertWon()
            //                }
            //            }
            
        } else {
            
        }
        //            else if collision == PhysicsCategory.resident.rawValue{
        //                print("eat white")
        //                whiteResi.removeAllChildren()
        //            }
        
        
        
        
        //                } else if contact.bodyA.categoryBitMask == Collision.FinishHole || contact.bodyB.categoryBitMask == Collision.FinishHole {
        //                    alertWon()
        //                }
        //            }
        
        
        
        
        //        else if collision == PhysicsCategory.resident2.rawValue{
        //            print("eat red")
        //            redResi.removeAllChildren()
        //        }
        //
        //        else if collision == PhysicsCategory.resident3.rawValue{
        //            print("eat green")
        //            greenResi.removeAllChildren()
        //        }
        //
    }
}
