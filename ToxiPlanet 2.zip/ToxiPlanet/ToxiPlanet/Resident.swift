////
////  Resident.swift
////  ToxiPlanet
////
////  Created by Lujain Yhia on 25/10/1445 AH.
////
//
//import SpriteKit
//
//
//class Resident: SKNode {
//    
//    let resident: SKSpriteNode
//    
//    override init() {
//        let texture = SKTexture(imageNamed: "redResident")
//        resident = SKSpriteNode(texture: texture, color: .white, size: CGSize(width: 30, height: 30))
//        resident.position = CGPoint(x: -140, y: 205)
//        resident.physicsBody = SKPhysicsBody(circleOfRadius: 15)
//        resident.physicsBody?.isDynamic = false
//        resident.physicsBody?.affectedByGravity = false
//        resident.physicsBody?.categoryBitMask = PhysicsCategory.resident
//        resident.physicsBody?.collisionBitMask = PhysicsCategory.player
//        resident.physicsBody?.contactTestBitMask = PhysicsCategory.player
//        super.init()
//        
//        addChild(resident)
//        
//            }
//    
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//}
//
//





import SpriteKit

class Resident: SKNode {
    
    let residents: [ResidentModel]
//    let resident: SKSpriteNode
//    let resident2: SKSpriteNode
//    let resident3: SKSpriteNode
    
    init(residents: [ResidentModel]) {
        self.residents = residents
        super.init()

        for item in residents {
            let texture = SKTexture(imageNamed: item.texture)
            let resident = SKSpriteNode(texture: texture, color: .white, size: CGSize(width: 30, height: 30))
            resident.position = item.position
            resident.physicsBody = SKPhysicsBody(circleOfRadius: 15)
            resident.physicsBody?.isDynamic = false
            resident.physicsBody?.affectedByGravity = false
            resident.physicsBody?.categoryBitMask = PhysicsCategory.resident.rawValue
            resident.physicsBody?.collisionBitMask = PhysicsCategory.player.rawValue
            resident.physicsBody?.contactTestBitMask = PhysicsCategory.player.rawValue
            
            addChild(resident)
        }
    }
    
//    override init() {
//        // Initialize resident1
//        let texture = SKTexture(imageNamed: "whiteResident")
//        resident = SKSpriteNode(texture: texture, color: .white, size: CGSize(width: 30, height: 30))
//        resident.position = CGPoint(x: -140, y: 205)
//        resident.physicsBody = SKPhysicsBody(circleOfRadius: 15)
//        resident.physicsBody?.isDynamic = false
//        resident.physicsBody?.affectedByGravity = false
//        resident.physicsBody?.categoryBitMask = PhysicsCategory.resident.rawValue
//        resident.physicsBody?.collisionBitMask = PhysicsCategory.player.rawValue
//        resident.physicsBody?.contactTestBitMask = PhysicsCategory.player.rawValue
//        
//        // Initialize resident2
//        let texture2 = SKTexture(imageNamed: "redResident")
//        resident2 = SKSpriteNode(texture: texture2, color: .white, size: CGSize(width: 30, height: 30))
//        resident2.position = CGPoint(x: 50, y: 130)
//        resident2.physicsBody = SKPhysicsBody(circleOfRadius: 15)
//        resident2.physicsBody?.isDynamic = false
//        resident2.physicsBody?.affectedByGravity = false
//        resident2.physicsBody?.categoryBitMask = PhysicsCategory.resident2.rawValue
//        resident2.physicsBody?.collisionBitMask = PhysicsCategory.player.rawValue
//        resident2.physicsBody?.contactTestBitMask = PhysicsCategory.player.rawValue
//        
//        // Initialize resident3
//        let texture3 = SKTexture(imageNamed: "greenResident")
//        resident3 = SKSpriteNode(texture: texture3, color: .white, size: CGSize(width: 30, height: 30))
//        resident3.position = CGPoint(x: -115, y: 130)
//        resident3.physicsBody = SKPhysicsBody(circleOfRadius: 15)
//        resident3.physicsBody?.isDynamic = false
//        resident3.physicsBody?.affectedByGravity = false
//        resident3.physicsBody?.categoryBitMask = PhysicsCategory.resident3.rawValue
//        resident3.physicsBody?.collisionBitMask = PhysicsCategory.player.rawValue
//        resident3.physicsBody?.contactTestBitMask = PhysicsCategory.player.rawValue
//        
//        super.init()
//        
//        // Add both residents as children of the SKNode
//        addChild(resident)
//        addChild(resident2)
//        addChild(resident3)
//    }
//    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
