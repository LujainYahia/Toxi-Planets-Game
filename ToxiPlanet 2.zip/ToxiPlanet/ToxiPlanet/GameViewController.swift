//
//  GameViewController.swift
//  ToxiPlanet
//
//  Created by Lujain Yhia on 20/10/1445 AH.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {

    var currentLevel: GameLevels = GameLevelsManager.getLevel(.level1)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            
            if let scene = SKScene(fileNamed: currentLevel.fileName) {
                
                if let game = scene as? MainGameScene {
                    
                    let player = Player(playerPosition: currentLevel.playerePostion)
                    game.setPlayerResident(toxi: player,
                                           resident: currentLevel.resident)
                }
                // Set the scale mode to scale to fit the window
                scene.scaleMode = .aspectFill
                
                // Present the scene
                view.presentScene(scene)
            }

//            if let scene = SKScene(fileNamed: "Level1") {
//                // Set the scale mode to scale to fit the window
//                scene.scaleMode = .aspectFill
//                
//                // Present the scene
//                view.presentScene(scene)
//            }
            
            view.ignoresSiblingOrder = true
            view.showsPhysics = true
            view.showsFPS = true
            view.showsNodeCount = true
        }
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}
