//
//  Player.swift
//  ToxiPlanet
//
//  Created by Lujain Yhia on 21/10/1445 AH.
//

import SpriteKit


//enum Collision: UInt32 {
//    case BlackHole = 9
//    case FinishHole = 8
//}

class Player: SKNode {
    
    var player: SKSpriteNode
    var playerPosition: CGPoint
    
    init(playerPosition: CGPoint) {
        self.playerPosition = playerPosition
        
        let texture = SKTexture(imageNamed: "Toxi")
        player = SKSpriteNode(texture: texture, color: .white, size: texture.size())
        super.init()

        player.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        player.physicsBody?.isDynamic = true
        player.physicsBody?.categoryBitMask = PhysicsCategory.player.rawValue
        player.physicsBody?.collisionBitMask = PhysicsCategory.wall.rawValue | PhysicsCategory.BlackHole.rawValue
        player.physicsBody?.contactTestBitMask = PhysicsCategory.wall.rawValue | PhysicsCategory.BlackHole.rawValue
//        player.physicsBody?.contactTestBitMask = PhysicsCategory.wall.rawValue | PhysicsCategory.BlackHole.rawValue | Collision.FinishHole.rawValue
        
        addChild(player)
        centerToxi() // Call centerToxi() after adding the player sprite

    }
    
//    override init() {
//        
//        let texture = SKTexture(imageNamed: "Toxi")
//        player = SKSpriteNode(texture: texture, color: .white, size: texture.size())
//        super.init()
//
//        player.physicsBody = SKPhysicsBody(circleOfRadius: 10)
//        player.physicsBody?.isDynamic = true
//        player.physicsBody?.categoryBitMask = PhysicsCategory.player.rawValue
//        player.physicsBody?.collisionBitMask = PhysicsCategory.wall.rawValue | PhysicsCategory.BlackHole.rawValue
//        player.physicsBody?.contactTestBitMask = PhysicsCategory.wall.rawValue | PhysicsCategory.BlackHole.rawValue
////        player.physicsBody?.contactTestBitMask = PhysicsCategory.wall.rawValue | PhysicsCategory.BlackHole.rawValue | Collision.FinishHole.rawValue
//        
//        addChild(player)
//        centerToxi() // Call centerToxi() after adding the player sprite
//    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func centerToxi() {
        player.position = CGPoint(x: 80, y: 50)
        player.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        player.setScale(1)
        player.zPosition = 0.0
    }
}
