//
//  GameLevels.swift
//  ToxiPlanet
//
//  Created by Lujain Yhia on 27/10/1445 AH.
//

import Foundation

class GameLevelsManager {
    
    class func getLevel(_ level: Levels) -> GameLevels {
        switch level {
        case .level1:
            level1()
        case .level2:
            level2()
        default:
            level1()
        }
    }
 
//    class func getLevel(_ level: Levels) -> GameLevels {
//        switch level {
//        case .level1:
//            level2()
//        case .level2:
//            level2()
//        default:
//            level1()
//        }
//    }

    class func level1() -> GameLevels {
        
        let resident1 = ResidentModel(texture: "whiteResident", position: CGPoint(x: -140, y: 205))
        let resident2 = ResidentModel(texture: "redResident", position: CGPoint(x: 50, y: 130))
        let resident3 = ResidentModel(texture: "greenResident", position: CGPoint(x: -115, y: 130))
    
        let resident = Resident(residents: [resident1, resident2, resident3])

        return GameLevels(fileName: "Level1",
                          playerePostion: CGPoint(x: 80, y: 50),
                          resident: resident)
    }
    
    class func level2() -> GameLevels {
        
        let resident1 = ResidentModel(texture: "whiteResident", position: CGPoint(x: -140, y: 205))
        let resident2 = ResidentModel(texture: "redResident", position: CGPoint(x: 50, y: 130))
        let resident3 = ResidentModel(texture: "greenResident", position: CGPoint(x: -115, y: 130))
        
        let resident = Resident(residents: [resident1, resident2, resident3])
    
        return GameLevels(fileName: "Level2",
                          playerePostion: CGPoint(x: 80, y: 50),
                          resident: resident)
    }
}

enum Levels {
    case level1
    case level2
    case level3
    case level4
    case level5
    case level6
}
struct GameLevels {
    let fileName: String
    let playerePostion: CGPoint
    var resident: Resident
}

struct ResidentModel {
    let texture: String
    let position: CGPoint
}
